# FactSkill
Fact skill model and lambda code to be used for publishing a simple fact skill
